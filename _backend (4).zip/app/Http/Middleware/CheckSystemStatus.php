<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class CheckSystemStatus
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $systemStatus = DB::table('settings')->where('key', 'system_status')->value('value');
        
        // If the system is "off" (value is false), return a maintenance page
        if ($systemStatus == 'false' ) {
            return response()->json([
                'message' => 'The system is currently under maintenance. Please try again later.',
                'status' => 404,
                'type' => 'error'
            ],503); // You can create a custom maintenance view
        }
        return $next($request);
    }
}
