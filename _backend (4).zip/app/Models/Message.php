<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    use HasFactory;
    protected $fillable = ['user_id','subject','message','status'];
    public function user()
    {
       return  $this->belongsTo(User::Class , 'user_id');
    }

}
